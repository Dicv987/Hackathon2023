import cv2
import mediapipe as mp


face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

mp_drawing = mp.solutions.drawing_utils
mp_hands = mp.solutions.hands
cap = cv2.VideoCapture(1, cv2.CAP_DSHOW)

with mp_hands.Hands(
    static_image_mode = False ,
    max_num_hands = 10,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5) as hands:
    while True:
        ret, frame = cap.read()
        _, img = cap.read()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.1, 4)

        # Toda accion que se haga mientras tenga detectada la cara será dentro de este for
        for (x, y, w, h) in faces:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)

        k = cv2.waitKey(30)

        if not ret:
            break

        height, width, _ = frame.shape
        frame = cv2.flip(frame, 1)
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        results = hands.process(frame_rgb)

        if results.multi_hand_landmarks is not None:
            for hand_lankmarks in results.multi_hand_landmarks:
                mp_drawing.draw_landmarks(frame, hand_lankmarks, mp_hands.HAND_CONNECTIONS)

        cv2.imshow("Frame", frame)
        if cv2.waitKey(1) & 0xFF == 27:
            break
cap.release()
cv2.destroyAllWindows()


